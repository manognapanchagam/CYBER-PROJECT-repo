IRSP LOGIN ANOMALY DETECTION PORTAL — LAN + ADMIN ACCESS

1. Install Python 3.10+.
2. Open PowerShell in this folder.
3. Run: py -m pip install -r requirements.txt
4. Run: py app.py
5. On the administrator laptop, open http://127.0.0.1:5000 and sign in as:
   admin / Admin@12345
6. Friends on the same LAN open http://<ADMIN-LAPTOP-IP>:5000 and sign in as:
   student01 / Student@12345
   staff01 / Staff@12345

Important:
- Keep the terminal running while friends use the portal.
- If friends cannot connect, allow Python through Windows Firewall for Private networks and confirm both devices are on the same Wi-Fi/LAN. Some campus/office Wi-Fi networks block device-to-device connections (client isolation); use an approved network if so.
- Admin dashboard HTML and all admin APIs are restricted to localhost requests, so use 127.0.0.1 on the administrator laptop.
- This is a student demo, not production-ready. Change demo passwords and set IRSP_SECRET_KEY before any deployment. Do not expose this app directly to the public internet.
- The app only records login attempts made through this portal. Browser/OS and device ID are browser-derived metadata, not verified hardware identity; private LAN IPs cannot be accurately geolocated.
