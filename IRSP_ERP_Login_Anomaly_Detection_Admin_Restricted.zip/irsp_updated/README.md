# IRSP — ERP Login Anomaly Detection Portal

A local full-stack demonstration of login monitoring for an ERP-style application. It includes a Flask backend, SQLite database, authentication, a responsive admin dashboard, login-event collection, transparent rule-based risk scoring, event details, anomaly review, known-device history, and CSV export.

## Technology stack

- **Frontend:** HTML, CSS, JavaScript
- **Backend:** Python + Flask
- **Database:** SQLite (`irsp.db` is created automatically)
- **Detection logic:** Rule-based risk scoring (not a trained AI/ML model)

## Run on Windows

1. Install Python 3.10 or newer from the official Python website. During installation, enable **Add Python to PATH**.
2. Extract the ZIP into a normal folder.
3. Double-click `run.bat`. On the first run, it creates a virtual environment and installs Flask. An internet connection is needed for this first package installation.
4. Open **http://127.0.0.1:5000** in your browser.
5. Keep the terminal window open while testing. Press `Ctrl+C` to stop the server.

## Demo accounts

| Account | Username | Password | What happens |
|---|---|---|---|
| Security administrator | `admin` | `Admin@12345` | Opens the security dashboard |
| Student | `student01` | `Student@12345` | Creates a student login event and opens a demo ERP landing page |
| Staff | `staff01` | `Staff@12345` | Creates a staff login event and opens a demo ERP landing page |

These are demo-only credentials. Never reuse these passwords for real accounts or deploy them to a public server.

## How to demonstrate login anomalies

1. Sign in as `admin` and open the dashboard. The administrator's own login attempt is recorded.
2. Sign out, then sign in as `student01` and `staff01` using the same browser.
3. Sign out and sign in as `admin` again. The dashboard now shows the recorded attempts.
4. Try an incorrect password for a demo username. The failed attempt is recorded and appears in the review/alert area.
5. Sign in as `student01` once in your normal browser, then open a private/incognito window or another browser and sign in as `student01` again. A new browser-generated device identifier may trigger the “new device” rule.
6. Open a row with the arrow button to inspect browser, OS, device category, IP, approximate location, client timezone, screen size, timestamp, risk score, and reasons.
7. Use **Reports & export** to download the event records as CSV.

## What is recorded for each login attempt?

- Username (or the entered username for a failed attempt)
- Success/failure status
- Server-observed client IP address
- Browser and operating system inferred from the browser user-agent
- Broad device category (desktop/laptop, tablet, or mobile)
- A random device identifier stored in this browser's local storage
- Browser-reported timezone, language, and screen size
- Timestamp in UTC
- Approximate IP location when a public IP geolocation lookup succeeds
- Risk score, risk classification, and the rule reasons

## Detection rules

The demo applies transparent rules to successful logins:

- A new device for an account: +30
- Browser/OS profile differs from the known device profile: +10
- IP address not previously observed for that account: +20
- Login during late-night hours in the browser-reported timezone: +10
- Three or more failed attempts in the previous 10 minutes: +30

The score is capped at 100. The demo labels scores below 30 Low, 30–59 Medium, and 60+ High. Failed attempts are labeled **Review**. These are example rules and thresholds for a student demonstration, not a validated production security policy.

## Important accuracy and privacy notes

- **This is a working full-stack demo, not a production security system.** It records login attempts made through this app. It does not monitor logins to another ERP website unless that ERP is integrated with this backend or sends login events to an API.
- A high risk score is a warning, not proof that someone else is using the account. New devices, travel, VPNs, and shared networks can be legitimate.
- Browser and OS are inferred from the user-agent string and can be inaccurate. The device ID is browser-generated; it is not a hardware serial number and can be reset by clearing browser data.
- The IP is the address observed by Flask. When running locally it will normally be `127.0.0.1` or `::1`. LAN testing may show a private network address. Public-IP geolocation cannot identify an exact home, room, or laptop.
- For public IP addresses, the demo optionally attempts a public IP-geolocation lookup using ipapi.co. That service may receive the public IP address; lookup may fail or be rate-limited. Local/private IPs are shown as local network/localhost. No GPS location or Wi-Fi SSID is collected.
- The app does not collect passwords in its event log. Passwords are stored as hashes in the SQLite users table.
- The default secret key and demo credentials are for local development only. Before any deployment, set a strong `IRSP_SECRET_KEY`, use HTTPS, configure secure cookies, add CSRF protection and rate limiting, review privacy requirements, and replace demo accounts.
- The project uses rule-based detection. It does not currently train or run Isolation Forest or another ML model.

## Database

The `irsp.db` SQLite file is created automatically next to `app.py` on first launch. It contains `users`, `login_events`, and `known_devices` tables. To reset demo data, stop the server and delete `irsp.db`; it will be recreated on the next run.

## Project structure

```text
IRSP_Login_Anomaly_Detection_Portal/
├── app.py
├── requirements.txt
├── run.bat
├── README.md
├── .gitignore
├── templates/
│   ├── login.html
│   ├── dashboard.html
│   └── user_home.html
└── static/
    ├── style.css
    └── app.js
```
