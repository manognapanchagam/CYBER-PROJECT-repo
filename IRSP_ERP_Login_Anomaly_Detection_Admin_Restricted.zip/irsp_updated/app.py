from flask import Flask, render_template, request, redirect, url_for, session, jsonify, flash
from werkzeug.security import generate_password_hash, check_password_hash
from functools import wraps
from datetime import datetime, timezone
from zoneinfo import ZoneInfo
import sqlite3, os, re, json, hashlib, secrets, ipaddress, urllib.request

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
DB_PATH = os.path.join(BASE_DIR, 'irsp.db')
app = Flask(__name__)
app.secret_key = os.environ.get('IRSP_SECRET_KEY', 'dev-only-change-this-secret-before-deployment-' + secrets.token_hex(8))
app.config.update(SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE='Lax')

RISK_RULES = {
    'new_device': 30,
    'new_browser_or_os': 10,
    'new_ip': 20,
    'unusual_hour': 10,
    'repeated_failures': 30,
}


def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def now_iso():
    return datetime.now(timezone.utc).isoformat(timespec='seconds')


def init_db():
    conn = db()
    conn.executescript('''
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT UNIQUE NOT NULL,
      display_name TEXT NOT NULL,
      password_hash TEXT NOT NULL,
      role TEXT NOT NULL DEFAULT 'user',
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS login_events (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT NOT NULL,
      display_name TEXT,
      status TEXT NOT NULL,
      ip_address TEXT,
      browser TEXT,
      os_name TEXT,
      device_type TEXT,
      device_id TEXT,
      user_agent TEXT,
      timezone_name TEXT,
      language TEXT,
      screen_size TEXT,
      location TEXT,
      risk_score INTEGER NOT NULL DEFAULT 0,
      risk_level TEXT NOT NULL DEFAULT 'Low',
      anomaly_reasons TEXT NOT NULL DEFAULT '[]',
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS known_devices (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT NOT NULL,
      device_id TEXT NOT NULL,
      browser TEXT,
      os_name TEXT,
      first_seen TEXT NOT NULL,
      last_seen TEXT NOT NULL,
      UNIQUE(username, device_id)
    );
    CREATE INDEX IF NOT EXISTS idx_events_created ON login_events(created_at DESC);
    CREATE INDEX IF NOT EXISTS idx_events_user ON login_events(username);
    ''')
    starter = [
      ('admin', 'Security Administrator', 'Admin@12345', 'admin'),
      ('student01', 'Demo Student', 'Student@12345', 'user'),
      ('staff01', 'Demo Staff', 'Staff@12345', 'user'),
    ]
    for username, display_name, password, role in starter:
        existing = conn.execute('SELECT id FROM users WHERE username=?', (username,)).fetchone()
        if not existing:
            conn.execute('INSERT INTO users(username,display_name,password_hash,role,created_at) VALUES(?,?,?,?,?)',
                          (username, display_name, generate_password_hash(password), role, now_iso()))
    conn.commit()
    conn.close()


def get_client_ip():
    # Do not trust forwarded headers unless the app is behind a configured trusted proxy.
    return request.remote_addr or 'Unknown'


def parse_user_agent(ua):
    ua = ua or ''
    if 'Edg/' in ua: browser = 'Microsoft Edge'
    elif 'OPR/' in ua: browser = 'Opera'
    elif 'Firefox/' in ua: browser = 'Mozilla Firefox'
    elif 'Chrome/' in ua: browser = 'Google Chrome'
    elif 'Safari/' in ua and 'Chrome/' not in ua: browser = 'Safari'
    else: browser = 'Unknown browser'
    if 'Windows NT' in ua: os_name = 'Windows'
    elif 'Mac OS X' in ua or 'Macintosh' in ua: os_name = 'macOS'
    elif 'Android' in ua: os_name = 'Android'
    elif 'iPhone' in ua or 'iPad' in ua: os_name = 'iOS / iPadOS'
    elif 'Linux' in ua: os_name = 'Linux'
    else: os_name = 'Unknown OS'
    if re.search(r'Mobile|Android|iPhone', ua, re.I): device_type = 'Mobile'
    elif 'iPad' in ua or 'Tablet' in ua: device_type = 'Tablet'
    else: device_type = 'Desktop / Laptop'
    return browser, os_name, device_type


def approximate_location(ip, tz):
    # Private, loopback and link-local IPs cannot be geolocated from public IP databases.
    try:
        addr = ipaddress.ip_address(ip)
        if addr.is_private or addr.is_loopback or addr.is_link_local:
            return 'Local network / localhost'
    except ValueError:
        return 'Unavailable'
    # Optional public IP lookup. The app continues to work if this service is unreachable.
    try:
        req = urllib.request.Request(f'https://ipapi.co/{ip}/json/', headers={'User-Agent': 'IRSP-Student-Project/1.0'})
        with urllib.request.urlopen(req, timeout=1.5) as resp:
            data = json.loads(resp.read().decode('utf-8'))
        city, region, country = data.get('city'), data.get('region'), data.get('country_name')
        parts = [x for x in [city, region, country] if x]
        return ', '.join(parts) if parts else 'Unavailable'
    except Exception:
        return 'Unavailable (IP lookup not reachable)'


def risk_assessment(conn, username, device_id, browser, os_name, ip, timezone_name, status):
    score, reasons = 0, []
    if status != 'Success':
        return min(100, 15), ['Invalid username or password']
    known = conn.execute('SELECT * FROM known_devices WHERE username=? AND device_id=?', (username, device_id)).fetchone()
    any_devices = conn.execute('SELECT COUNT(*) AS n FROM known_devices WHERE username=?', (username,)).fetchone()['n']
    if device_id and not known and any_devices > 0:
        score += RISK_RULES['new_device']; reasons.append('New device for this account')
    if known and ((known['browser'] and known['browser'] != browser) or (known['os_name'] and known['os_name'] != os_name)):
        score += RISK_RULES['new_browser_or_os']; reasons.append('Browser or operating system differs from known device profile')
    prior_ips = conn.execute("SELECT COUNT(*) AS n FROM login_events WHERE username=? AND status='Success' AND ip_address=?", (username, ip)).fetchone()['n']
    prior_success = conn.execute("SELECT COUNT(*) AS n FROM login_events WHERE username=? AND status='Success'", (username,)).fetchone()['n']
    if prior_success > 0 and prior_ips == 0:
        score += RISK_RULES['new_ip']; reasons.append('IP address not previously observed for this account')
    try:
        local_hour = datetime.now(ZoneInfo(timezone_name)).hour if timezone_name else datetime.now().hour
    except Exception:
        local_hour = datetime.now().hour
    if local_hour < 5 or local_hour >= 23:
        score += RISK_RULES['unusual_hour']; reasons.append('Login occurred during late-night hours')
    cutoff = datetime.now(timezone.utc).timestamp() - 10 * 60
    rows = conn.execute("SELECT created_at FROM login_events WHERE username=? AND status='Failed'", (username,)).fetchall()
    recent_fails = 0
    for row in rows:
        try:
            if datetime.fromisoformat(row['created_at']).timestamp() >= cutoff: recent_fails += 1
        except Exception: pass
    if recent_fails >= 3:
        score += RISK_RULES['repeated_failures']; reasons.append('Multiple failed login attempts in the last 10 minutes')
    score = min(100, score)
    level = 'High' if score >= 60 else 'Medium' if score >= 30 else 'Low'
    if not reasons: reasons = ['No configured anomaly rule was triggered']
    return score, reasons


def log_event(username, display_name, status, metadata):
    conn = db()
    ip = get_client_ip()
    ua = request.headers.get('User-Agent', '')
    browser, os_name, device_type = parse_user_agent(ua)
    device_id = (metadata.get('deviceId') or '')[:128]
    timezone_name = (metadata.get('timezone') or '')[:80]
    language = (metadata.get('language') or '')[:80]
    screen_size = (metadata.get('screenSize') or '')[:40]
    score, reasons = risk_assessment(conn, username, device_id, browser, os_name, ip, timezone_name, status)
    calculated_level = 'High' if score >= 60 else 'Medium' if score >= 30 else 'Low'
    location = approximate_location(ip, timezone_name)
    conn.execute('''INSERT INTO login_events(username,display_name,status,ip_address,browser,os_name,device_type,device_id,user_agent,timezone_name,language,screen_size,location,risk_score,risk_level,anomaly_reasons,created_at)
                    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)''',
                 (username, display_name, status, ip, browser, os_name, device_type, device_id, ua[:500], timezone_name, language, screen_size, location, score, calculated_level if status == 'Success' else 'Review', json.dumps(reasons), now_iso()))
    if status == 'Success' and device_id:
        conn.execute('''INSERT INTO known_devices(username,device_id,browser,os_name,first_seen,last_seen) VALUES(?,?,?,?,?,?)
          ON CONFLICT(username,device_id) DO UPDATE SET browser=excluded.browser, os_name=excluded.os_name, last_seen=excluded.last_seen''',
          (username, device_id, browser, os_name, now_iso(), now_iso()))
    conn.commit()
    event_id = conn.execute('SELECT last_insert_rowid()').fetchone()[0]
    conn.close()
    return {'id': event_id, 'risk_score': score, 'risk_level': calculated_level if status == 'Success' else 'Review', 'reasons': reasons}


def login_required(fn):
    @wraps(fn)
    def wrapped(*args, **kwargs):
        if not session.get('username'):
            return redirect(url_for('login'))
        return fn(*args, **kwargs)
    return wrapped


def is_local_admin_request():
    """Allow admin-only pages/APIs only from the server laptop itself.

    This demo uses request.remote_addr; do not place it behind a proxy unless
    the proxy and forwarded headers are explicitly configured and trusted.
    """
    return (request.remote_addr or '') in {'127.0.0.1', '::1'}


def admin_required(fn):
    @wraps(fn)
    def wrapped(*args, **kwargs):
        if not session.get('username'):
            return jsonify({'error': 'Please sign in'}), 401
        if session.get('role') != 'admin':
            return jsonify({'error': 'Administrator access required'}), 403
        if not is_local_admin_request():
            return jsonify({'error': 'Admin access is restricted to the administrator laptop.'}), 403
        return fn(*args, **kwargs)
    return wrapped


@app.route('/')
def home():
    if session.get('role') == 'admin': return redirect(url_for('dashboard'))
    if session.get('username'): return render_template('user_home.html', name=session.get('display_name'))
    return redirect(url_for('login'))


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'GET':
        if session.get('role') == 'admin': return redirect(url_for('dashboard'))
        return render_template('login.html')
    username = (request.form.get('username') or '').strip()[:80]
    password = request.form.get('password') or ''
    try: metadata = json.loads(request.form.get('metadata') or '{}')
    except json.JSONDecodeError: metadata = {}
    conn = db()
    user = conn.execute('SELECT * FROM users WHERE username=?', (username,)).fetchone()
    conn.close()
    if not user or not check_password_hash(user['password_hash'], password):
        log_event(username or 'unknown', username or 'Unknown user', 'Failed', metadata)
        flash('Invalid username or password. The attempt has been recorded.', 'error')
        return redirect(url_for('login'))
    # Do not create an administrator session from another laptop on the LAN.
    if user['role'] == 'admin' and not is_local_admin_request():
        log_event(user['username'], user['display_name'], 'Failed', metadata)
        flash('Administrator sign-in is allowed only on the administrator laptop.', 'error')
        return redirect(url_for('login'))
    event = log_event(user['username'], user['display_name'], 'Success', metadata)
    session.clear()
    session['username'] = user['username']
    session['display_name'] = user['display_name']
    session['role'] = user['role']
    session['last_login_event'] = event['id']
    if user['role'] == 'admin': return redirect(url_for('dashboard'))
    return redirect(url_for('home'))


@app.route('/logout', methods=['POST', 'GET'])
def logout():
    session.clear()
    return redirect(url_for('login'))


@app.route('/dashboard')
@login_required
def dashboard():
    if session.get('role') != 'admin':
        return redirect(url_for('home'))
    # Protect the HTML page too, not just its data APIs.
    if not is_local_admin_request():
        session.clear()
        flash('Administrator dashboard is available only on the administrator laptop.', 'error')
        return redirect(url_for('login'))
    return render_template('dashboard.html', name=session.get('display_name'))


@app.route('/api/summary')
@admin_required
def api_summary():
    conn = db()
    total = conn.execute('SELECT COUNT(*) n FROM login_events').fetchone()['n']
    successful = conn.execute("SELECT COUNT(*) n FROM login_events WHERE status='Success'").fetchone()['n']
    failed = conn.execute("SELECT COUNT(*) n FROM login_events WHERE status='Failed'").fetchone()['n']
    anomalies = conn.execute("SELECT COUNT(*) n FROM login_events WHERE (risk_score >= 30 OR status='Failed')").fetchone()['n']
    high = conn.execute("SELECT COUNT(*) n FROM login_events WHERE risk_score >= 60 AND status='Success'").fetchone()['n']
    conn.close()
    return jsonify({'total': total, 'successful': successful, 'failed': failed, 'anomalies': anomalies, 'highRisk': high})


@app.route('/api/events')
@admin_required
def api_events():
    search = (request.args.get('search') or '').strip()[:100]
    status = (request.args.get('status') or '').strip()
    risk = (request.args.get('risk') or '').strip()
    limit = min(max(int(request.args.get('limit', 250)), 1), 500)
    query = 'SELECT * FROM login_events WHERE 1=1'
    args = []
    if search:
        query += ' AND (username LIKE ? OR ip_address LIKE ? OR browser LIKE ? OR location LIKE ?)'
        args.extend([f'%{search}%'] * 4)
    if status in ('Success', 'Failed'):
        query += ' AND status=?'; args.append(status)
    if risk in ('Low', 'Medium', 'High', 'Review'):
        query += ' AND risk_level=?'; args.append(risk)
    query += ' ORDER BY id DESC LIMIT ?'; args.append(limit)
    conn = db(); rows = conn.execute(query, args).fetchall(); conn.close()
    output = []
    for row in rows:
        item = dict(row)
        try: item['anomaly_reasons'] = json.loads(item['anomaly_reasons'])
        except Exception: item['anomaly_reasons'] = []
        output.append(item)
    return jsonify(output)


@app.route('/api/events/<int:event_id>')
@admin_required
def api_event_detail(event_id):
    conn = db(); row = conn.execute('SELECT * FROM login_events WHERE id=?', (event_id,)).fetchone(); conn.close()
    if not row: return jsonify({'error': 'Event not found'}), 404
    item = dict(row)
    try: item['anomaly_reasons'] = json.loads(item['anomaly_reasons'])
    except Exception: item['anomaly_reasons'] = []
    return jsonify(item)


@app.route('/api/devices')
@admin_required
def api_devices():
    conn = db()
    rows = conn.execute('''SELECT username, device_id, browser, os_name, first_seen, last_seen FROM known_devices ORDER BY last_seen DESC''').fetchall()
    conn.close(); return jsonify([dict(x) for x in rows])


@app.route('/api/export.csv')
@admin_required
def export_csv():
    import csv, io
    conn = db(); rows = conn.execute('SELECT id,username,status,ip_address,browser,os_name,device_type,location,timezone_name,risk_score,risk_level,anomaly_reasons,created_at FROM login_events ORDER BY id DESC').fetchall(); conn.close()
    output = io.StringIO(); writer = csv.writer(output)
    writer.writerow(['Event ID','Username','Status','IP Address','Browser','Operating System','Device Type','Location','Timezone','Risk Score','Risk Level','Reasons','Timestamp'])
    for r in rows: writer.writerow(list(r))
    from flask import Response
    return Response('\ufeff' + output.getvalue(), mimetype='text/csv', headers={'Content-Disposition':'attachment; filename=irsp-login-events.csv'})


@app.route('/health')
def health(): return jsonify({'status':'ok', 'application':'IRSP Login Anomaly Detection Portal'})


init_db()
if __name__ == '__main__':
    app.run(host='0.0.0.0', port=int(os.environ.get('PORT', 5000)), debug=False)
