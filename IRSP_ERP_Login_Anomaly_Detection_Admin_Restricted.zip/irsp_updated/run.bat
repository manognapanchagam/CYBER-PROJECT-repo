@echo off
setlocal
cd /d "%~dp0"
echo ================================================
echo  IRSP - Login Anomaly Detection Portal
echo ================================================
where py >nul 2>nul
if errorlevel 1 (
  echo Python launcher ^(py^) was not found. Install Python 3.10+ and enable Add Python to PATH.
  pause
  exit /b 1
)
if not exist .venv\Scripts\python.exe (
  echo Creating local Python environment...
  py -m venv .venv
  if errorlevel 1 goto error
)
echo Installing required package if needed...
.venv\Scripts\python.exe -m pip install -r requirements.txt
if errorlevel 1 goto error
echo.
echo Open http://127.0.0.1:5000 in your browser.
echo Keep this window open while using the portal.
echo Press Ctrl+C to stop the server.
.venv\Scripts\python.exe app.py
goto end
:error
echo.
echo Setup failed. Check your Python installation and internet connection for package installation.
pause
:end
endlocal
